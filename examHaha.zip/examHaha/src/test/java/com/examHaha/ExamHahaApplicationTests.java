package com.examHaha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamHahaApplicationTests {

	@Test
	void contextLoads() {
	}

}
